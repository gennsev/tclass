### Data
Train and test data from https://www.cs.umb.edu/~smimarog/textmining/datasets/
